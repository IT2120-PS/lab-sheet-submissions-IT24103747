setwd("C:\\Users\\it24103747\\Desktop\\IT24103747\\IT24103747_Lab 4")
getwd()

data<-read.table("DATA 4.txt",header=TRUE,sep="")
fix(data)
attach(data)

boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)


hist(X1,ylab="Frequency",xlab="Team Attendence",main="Histogram for Team Attendence")
hist(X2,ylab="Frequency",xlab="Team Salary",main="Histogram for Team Salary")
hist(X3,ylab="Frequency",xlab="Year",main="Histogram for Years")

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

IQR(X1)
IQR(X2)
IQR(X3)










branch_data<-read.csv("Exercise.txt")
fix(branch_data)
head(branch_data)
attach(branch_data)

str(branch_data)

boxplot(Sales_X1, main = "Boxplot for Sales",outline=TRUE,outpch=8,horizontal=TRUE)

fivenum(branch_data$Advertising, na.rm = TRUE)

IQR(branch_data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

outliers_years <- find_outliers(branch_data$years)
print(outliers_years)



